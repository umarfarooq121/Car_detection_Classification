# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'App.ui'
##
## Created by: Qt User Interface Compiler version 5.14.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import (QCoreApplication, QMetaObject, QObject, QPoint,
    QRect, QSize, QUrl, Qt)
from PySide2.QtGui import (QBrush, QColor, QConicalGradient, QFont,
    QFontDatabase, QIcon, QLinearGradient, QPalette, QPainter, QPixmap,
    QRadialGradient)
from PySide2.QtWidgets import *

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(800, 600)
        MainWindow.setMaximumSize(QSize(1080, 720))
        MainWindow.setStyleSheet(u"QPushButton{\n"
"background:#00BFFF}")
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.centralwidget.setEnabled(True)
        self.gridLayout_5 = QGridLayout(self.centralwidget)
        self.gridLayout_5.setObjectName(u"gridLayout_5")
        self.frame_4 = QFrame(self.centralwidget)
        self.frame_4.setObjectName(u"frame_4")
        self.frame_4.setStyleSheet(u"background-color: rgb(0, 0, 0);")
        self.frame_4.setFrameShape(QFrame.StyledPanel)
        self.frame_4.setFrameShadow(QFrame.Raised)
        self.verticalLayout_2 = QVBoxLayout(self.frame_4)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.label_16 = QLabel(self.frame_4)
        self.label_16.setObjectName(u"label_16")
        font = QFont()
        font.setFamily(u"Calibri")
        font.setPointSize(26)
        font.setBold(True)
        font.setWeight(75);
        self.label_16.setFont(font)
        self.label_16.setStyleSheet(u"color: rgb(255, 255, 255);")

        self.verticalLayout_2.addWidget(self.label_16)


        self.gridLayout_5.addWidget(self.frame_4, 0, 0, 2, 2)

        self.tabWidget = QTabWidget(self.centralwidget)
        self.tabWidget.setObjectName(u"tabWidget")
        font1 = QFont()
        font1.setFamily(u"Calibri")
        font1.setPointSize(16)
        font1.setBold(True)
        font1.setWeight(75);
        self.tabWidget.setFont(font1)
        self.tabWidget.setStyleSheet(u"background-color: rgb(255, 255, 255);")
        self.tabWidget.setTabShape(QTabWidget.Rounded)
        self.tab = QWidget()
        self.tab.setObjectName(u"tab")
        font2 = QFont()
        font2.setFamily(u"Calibri")
        font2.setPointSize(12)
        font2.setBold(True)
        font2.setWeight(75);
        self.tab.setFont(font2)
        self.frame = QFrame(self.tab)
        self.frame.setObjectName(u"frame")
        self.frame.setGeometry(QRect(510, 80, 221, 301))
        self.frame.setStyleSheet(u"QFrame{\n"
"border-radius:20px;\n"
"\n"
"\n"
"background-color: rgb(85, 255, 255);\n"
"}")
        self.frame.setFrameShape(QFrame.StyledPanel)
        self.frame.setFrameShadow(QFrame.Raised)
        self.gridLayout = QGridLayout(self.frame)
        self.gridLayout.setObjectName(u"gridLayout")
        self.admin_log_2 = QLabel(self.frame)
        self.admin_log_2.setObjectName(u"admin_log_2")
        font3 = QFont()
        font3.setFamily(u"Calibri")
        font3.setPointSize(11)
        font3.setBold(False)
        font3.setWeight(50);
        self.admin_log_2.setFont(font3)

        self.gridLayout.addWidget(self.admin_log_2, 1, 1, 1, 1)

        self.label = QLabel(self.frame)
        self.label.setObjectName(u"label")
        self.label.setStyleSheet(u"image:url(:/image/login.png)")

        self.gridLayout.addWidget(self.label, 0, 1, 1, 1)

        self.label_2 = QLabel(self.frame)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setStyleSheet(u"image:url(:/image/user.png)")

        self.gridLayout.addWidget(self.label_2, 2, 0, 1, 1)

        self.UserId = QLineEdit(self.frame)
        self.UserId.setObjectName(u"UserId")
        self.UserId.setAutoFillBackground(False)
        self.UserId.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignVCenter)

        self.gridLayout.addWidget(self.UserId, 2, 1, 1, 1)

        self.label_3 = QLabel(self.frame)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setStyleSheet(u"image:url(:/image/key.png)")

        self.gridLayout.addWidget(self.label_3, 3, 0, 1, 1)

        self.UserId_2 = QLineEdit(self.frame)
        self.UserId_2.setObjectName(u"UserId_2")
        self.UserId_2.setAutoFillBackground(False)
        self.UserId_2.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignVCenter)

        self.gridLayout.addWidget(self.UserId_2, 3, 1, 1, 1)

        self.pushButton = QPushButton(self.frame)
        self.pushButton.setObjectName(u"pushButton")
        self.pushButton.setFont(font2)
        self.pushButton.setStyleSheet(u"background:#00BFFF;\n"
"border-radius:20px;\n"
"color:white;")
        icon = QIcon()
        icon.addFile(u":/image/tick.png", QSize(), QIcon.Normal, QIcon.Off)
        self.pushButton.setIcon(icon)

        self.gridLayout.addWidget(self.pushButton, 4, 1, 1, 1)

        self.tabWidget.addTab(self.tab, QString())
        self.tab_2 = QWidget()
        self.tab_2.setObjectName(u"tab_2")
        self.frame_2 = QFrame(self.tab_2)
        self.frame_2.setObjectName(u"frame_2")
        self.frame_2.setGeometry(QRect(510, 80, 221, 301))
        self.frame_2.setStyleSheet(u"background-color: rgb(85, 255, 255);\n"
"border-radius:20px;")
        self.frame_2.setFrameShape(QFrame.StyledPanel)
        self.frame_2.setFrameShadow(QFrame.Raised)
        self.gridLayout_3 = QGridLayout(self.frame_2)
        self.gridLayout_3.setObjectName(u"gridLayout_3")
        self.label_4 = QLabel(self.frame_2)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setStyleSheet(u"image:url(:/image/login.png)")

        self.gridLayout_3.addWidget(self.label_4, 0, 1, 1, 1)

        self.admin_log_3 = QLabel(self.frame_2)
        self.admin_log_3.setObjectName(u"admin_log_3")
        font4 = QFont()
        font4.setFamily(u"Calibri")
        font4.setPointSize(14)
        font4.setBold(False)
        font4.setWeight(50);
        self.admin_log_3.setFont(font4)

        self.gridLayout_3.addWidget(self.admin_log_3, 1, 1, 1, 1)

        self.label_5 = QLabel(self.frame_2)
        self.label_5.setObjectName(u"label_5")
        self.label_5.setStyleSheet(u"image:url(:/image/user.png)")

        self.gridLayout_3.addWidget(self.label_5, 2, 0, 1, 1)

        self.UserId_3 = QLineEdit(self.frame_2)
        self.UserId_3.setObjectName(u"UserId_3")
        self.UserId_3.setAutoFillBackground(False)
        self.UserId_3.setStyleSheet(u"border-color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);")
        self.UserId_3.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignVCenter)

        self.gridLayout_3.addWidget(self.UserId_3, 2, 1, 1, 1)

        self.label_6 = QLabel(self.frame_2)
        self.label_6.setObjectName(u"label_6")
        self.label_6.setStyleSheet(u"image:url(:/image/key.png)")

        self.gridLayout_3.addWidget(self.label_6, 3, 0, 1, 1)

        self.UserId_4 = QLineEdit(self.frame_2)
        self.UserId_4.setObjectName(u"UserId_4")
        self.UserId_4.setAutoFillBackground(False)
        self.UserId_4.setStyleSheet(u"background-color: rgb(255, 255, 255);")
        self.UserId_4.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignVCenter)

        self.gridLayout_3.addWidget(self.UserId_4, 3, 1, 1, 1)

        self.pushButton_2 = QPushButton(self.frame_2)
        self.pushButton_2.setObjectName(u"pushButton_2")
        self.pushButton_2.setFont(font2)
        self.pushButton_2.setStyleSheet(u"background:#00BFFF;\n"
"border-radius:20px;\n"
"color:white;")
        self.pushButton_2.setIcon(icon)

        self.gridLayout_3.addWidget(self.pushButton_2, 4, 0, 1, 2)

        self.tabWidget.addTab(self.tab_2, QString())
        self.tab_3 = QWidget()
        self.tab_3.setObjectName(u"tab_3")
        self.frame_3 = QFrame(self.tab_3)
        self.frame_3.setObjectName(u"frame_3")
        self.frame_3.setGeometry(QRect(10, 20, 751, 371))
        self.frame_3.setStyleSheet(u"background-color: rgb(85, 255, 255);")
        self.frame_3.setFrameShape(QFrame.StyledPanel)
        self.frame_3.setFrameShadow(QFrame.Raised)
        self.gridLayout_4 = QGridLayout(self.frame_3)
        self.gridLayout_4.setObjectName(u"gridLayout_4")
        self.horizontalLayout_4 = QHBoxLayout()
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.label_9 = QLabel(self.frame_3)
        self.label_9.setObjectName(u"label_9")
        font5 = QFont()
        font5.setFamily(u"Calibri")
        font5.setPointSize(15)
        font5.setBold(True)
        font5.setWeight(75);
        self.label_9.setFont(font5)

        self.horizontalLayout_4.addWidget(self.label_9)

        self.horizontalLayout_3 = QHBoxLayout()
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.radioButton = QRadioButton(self.frame_3)
        self.radioButton.setObjectName(u"radioButton")

        self.horizontalLayout_3.addWidget(self.radioButton)

        self.radioButton_2 = QRadioButton(self.frame_3)
        self.radioButton_2.setObjectName(u"radioButton_2")

        self.horizontalLayout_3.addWidget(self.radioButton_2)


        self.horizontalLayout_4.addLayout(self.horizontalLayout_3)


        self.gridLayout_4.addLayout(self.horizontalLayout_4, 1, 0, 1, 1)

        self.horizontalLayout_2 = QHBoxLayout()
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.label_8 = QLabel(self.frame_3)
        self.label_8.setObjectName(u"label_8")
        self.label_8.setFont(font5)

        self.horizontalLayout_2.addWidget(self.label_8)

        self.lineEdit_2 = QLineEdit(self.frame_3)
        self.lineEdit_2.setObjectName(u"lineEdit_2")
        self.lineEdit_2.setStyleSheet(u"background-color: rgb(255, 255, 255);")

        self.horizontalLayout_2.addWidget(self.lineEdit_2)


        self.gridLayout_4.addLayout(self.horizontalLayout_2, 0, 1, 1, 1)

        self.horizontalLayout_5 = QHBoxLayout()
        self.horizontalLayout_5.setObjectName(u"horizontalLayout_5")
        self.label_10 = QLabel(self.frame_3)
        self.label_10.setObjectName(u"label_10")
        self.label_10.setFont(font5)

        self.horizontalLayout_5.addWidget(self.label_10)

        self.lineEdit_3 = QLineEdit(self.frame_3)
        self.lineEdit_3.setObjectName(u"lineEdit_3")
        self.lineEdit_3.setStyleSheet(u"background-color: rgb(255, 255, 255);")
        self.lineEdit_3.setInputMethodHints(Qt.ImhEmailCharactersOnly)

        self.horizontalLayout_5.addWidget(self.lineEdit_3)


        self.gridLayout_4.addLayout(self.horizontalLayout_5, 1, 1, 1, 1)

        self.horizontalLayout_7 = QHBoxLayout()
        self.horizontalLayout_7.setObjectName(u"horizontalLayout_7")
        self.label_12 = QLabel(self.frame_3)
        self.label_12.setObjectName(u"label_12")
        self.label_12.setFont(font5)

        self.horizontalLayout_7.addWidget(self.label_12)

        self.lineEdit_4 = QLineEdit(self.frame_3)
        self.lineEdit_4.setObjectName(u"lineEdit_4")
        self.lineEdit_4.setStyleSheet(u"background-color: rgb(255, 255, 255);")
        self.lineEdit_4.setInputMethodHints(Qt.ImhNone)

        self.horizontalLayout_7.addWidget(self.lineEdit_4)


        self.gridLayout_4.addLayout(self.horizontalLayout_7, 2, 1, 1, 1)

        self.horizontalLayout_6 = QHBoxLayout()
        self.horizontalLayout_6.setObjectName(u"horizontalLayout_6")
        self.label_11 = QLabel(self.frame_3)
        self.label_11.setObjectName(u"label_11")
        self.label_11.setFont(font5)

        self.horizontalLayout_6.addWidget(self.label_11)

        self.comboBox = QComboBox(self.frame_3)
        self.comboBox.addItem(QString())
        self.comboBox.addItem(QString())
        self.comboBox.addItem(QString())
        self.comboBox.addItem(QString())
        self.comboBox.addItem(QString())
        self.comboBox.setObjectName(u"comboBox")
        self.comboBox.setStyleSheet(u"background-color: rgb(255, 255, 255);")

        self.horizontalLayout_6.addWidget(self.comboBox)


        self.gridLayout_4.addLayout(self.horizontalLayout_6, 2, 0, 1, 1)

        self.horizontalLayout_8 = QHBoxLayout()
        self.horizontalLayout_8.setObjectName(u"horizontalLayout_8")
        self.label_13 = QLabel(self.frame_3)
        self.label_13.setObjectName(u"label_13")
        self.label_13.setFont(font5)

        self.horizontalLayout_8.addWidget(self.label_13)

        self.lineEdit_5 = QLineEdit(self.frame_3)
        self.lineEdit_5.setObjectName(u"lineEdit_5")
        self.lineEdit_5.setStyleSheet(u"background-color: rgb(255, 255, 255);")
        self.lineEdit_5.setInputMethodHints(Qt.ImhNone)

        self.horizontalLayout_8.addWidget(self.lineEdit_5)


        self.gridLayout_4.addLayout(self.horizontalLayout_8, 3, 0, 1, 1)

        self.horizontalLayout_9 = QHBoxLayout()
        self.horizontalLayout_9.setObjectName(u"horizontalLayout_9")
        self.label_14 = QLabel(self.frame_3)
        self.label_14.setObjectName(u"label_14")
        self.label_14.setFont(font5)

        self.horizontalLayout_9.addWidget(self.label_14)

        self.lineEdit_6 = QLineEdit(self.frame_3)
        self.lineEdit_6.setObjectName(u"lineEdit_6")
        self.lineEdit_6.setStyleSheet(u"background-color: rgb(255, 255, 255);")
        self.lineEdit_6.setInputMethodHints(Qt.ImhNone)

        self.horizontalLayout_9.addWidget(self.lineEdit_6)


        self.gridLayout_4.addLayout(self.horizontalLayout_9, 3, 1, 1, 1)

        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.label_7 = QLabel(self.frame_3)
        self.label_7.setObjectName(u"label_7")
        self.label_7.setFont(font5)

        self.horizontalLayout.addWidget(self.label_7)

        self.lineEdit = QLineEdit(self.frame_3)
        self.lineEdit.setObjectName(u"lineEdit")
        self.lineEdit.setStyleSheet(u"background-color: rgb(255, 255, 255);")

        self.horizontalLayout.addWidget(self.lineEdit)


        self.gridLayout_4.addLayout(self.horizontalLayout, 0, 0, 1, 1)

        self.pushButton_3 = QPushButton(self.frame_3)
        self.pushButton_3.setObjectName(u"pushButton_3")
        self.pushButton_3.setFont(font1)
        self.pushButton_3.setStyleSheet(u"background:#00BFFF;\n"
"color:white;\n"
"border-radius:20px")

        self.gridLayout_4.addWidget(self.pushButton_3, 4, 0, 1, 2)

        self.tabWidget.addTab(self.tab_3, QString())
        self.tab_4 = QWidget()
        self.tab_4.setObjectName(u"tab_4")
        self.pushButton_4 = QPushButton(self.tab_4)
        self.pushButton_4.setObjectName(u"pushButton_4")
        self.pushButton_4.setGeometry(QRect(280, 380, 221, 61))
        font6 = QFont()
        font6.setFamily(u"Calibri")
        font6.setPointSize(18)
        font6.setBold(True)
        font6.setWeight(75);
        self.pushButton_4.setFont(font6)
        self.pushButton_4.setStyleSheet(u"background-color: #00BFFF;\n"
"color: rgb(255, 255, 255);\n"
"border-radius:15px")
        self.widget = QWidget(self.tab_4)
        self.widget.setObjectName(u"widget")
        self.widget.setGeometry(QRect(210, 60, 361, 26))
        self.horizontalLayout_10 = QHBoxLayout(self.widget)
        self.horizontalLayout_10.setObjectName(u"horizontalLayout_10")
        self.horizontalLayout_10.setContentsMargins(0, 0, 0, 0)
        self.label_17 = QLabel(self.widget)
        self.label_17.setObjectName(u"label_17")
        self.label_17.setFont(font5)

        self.horizontalLayout_10.addWidget(self.label_17)

        self.lineEdit_7 = QLineEdit(self.widget)
        self.lineEdit_7.setObjectName(u"lineEdit_7")

        self.horizontalLayout_10.addWidget(self.lineEdit_7)

        self.widget1 = QWidget(self.tab_4)
        self.widget1.setObjectName(u"widget1")
        self.widget1.setGeometry(QRect(210, 110, 361, 26))
        self.horizontalLayout_11 = QHBoxLayout(self.widget1)
        self.horizontalLayout_11.setObjectName(u"horizontalLayout_11")
        self.horizontalLayout_11.setContentsMargins(0, 0, 0, 0)
        self.label_18 = QLabel(self.widget1)
        self.label_18.setObjectName(u"label_18")
        self.label_18.setFont(font5)

        self.horizontalLayout_11.addWidget(self.label_18)

        self.comboBox_2 = QComboBox(self.widget1)
        self.comboBox_2.addItem(QString())
        self.comboBox_2.addItem(QString())
        self.comboBox_2.addItem(QString())
        self.comboBox_2.addItem(QString())
        self.comboBox_2.addItem(QString())
        self.comboBox_2.addItem(QString())
        self.comboBox_2.setObjectName(u"comboBox_2")

        self.horizontalLayout_11.addWidget(self.comboBox_2)

        self.widget2 = QWidget(self.tab_4)
        self.widget2.setObjectName(u"widget2")
        self.widget2.setGeometry(QRect(210, 160, 361, 26))
        self.horizontalLayout_12 = QHBoxLayout(self.widget2)
        self.horizontalLayout_12.setObjectName(u"horizontalLayout_12")
        self.horizontalLayout_12.setContentsMargins(0, 0, 0, 0)
        self.label_19 = QLabel(self.widget2)
        self.label_19.setObjectName(u"label_19")
        self.label_19.setFont(font5)

        self.horizontalLayout_12.addWidget(self.label_19)

        self.comboBox_3 = QComboBox(self.widget2)
        self.comboBox_3.addItem(QString())
        self.comboBox_3.addItem(QString())
        self.comboBox_3.addItem(QString())
        self.comboBox_3.addItem(QString())
        self.comboBox_3.addItem(QString())
        self.comboBox_3.addItem(QString())
        self.comboBox_3.addItem(QString())
        self.comboBox_3.addItem(QString())
        self.comboBox_3.addItem(QString())
        self.comboBox_3.setObjectName(u"comboBox_3")

        self.horizontalLayout_12.addWidget(self.comboBox_3)

        self.widget3 = QWidget(self.tab_4)
        self.widget3.setObjectName(u"widget3")
        self.widget3.setGeometry(QRect(210, 210, 361, 26))
        self.horizontalLayout_13 = QHBoxLayout(self.widget3)
        self.horizontalLayout_13.setObjectName(u"horizontalLayout_13")
        self.horizontalLayout_13.setContentsMargins(0, 0, 0, 0)
        self.label_20 = QLabel(self.widget3)
        self.label_20.setObjectName(u"label_20")
        self.label_20.setFont(font5)

        self.horizontalLayout_13.addWidget(self.label_20)

        self.comboBox_4 = QComboBox(self.widget3)
        self.comboBox_4.addItem(QString())
        self.comboBox_4.addItem(QString())
        self.comboBox_4.addItem(QString())
        self.comboBox_4.addItem(QString())
        self.comboBox_4.addItem(QString())
        self.comboBox_4.addItem(QString())
        self.comboBox_4.setObjectName(u"comboBox_4")

        self.horizontalLayout_13.addWidget(self.comboBox_4)

        self.widget4 = QWidget(self.tab_4)
        self.widget4.setObjectName(u"widget4")
        self.widget4.setGeometry(QRect(210, 260, 361, 26))
        self.horizontalLayout_14 = QHBoxLayout(self.widget4)
        self.horizontalLayout_14.setObjectName(u"horizontalLayout_14")
        self.horizontalLayout_14.setContentsMargins(0, 0, 0, 0)
        self.label_21 = QLabel(self.widget4)
        self.label_21.setObjectName(u"label_21")
        self.label_21.setFont(font5)

        self.horizontalLayout_14.addWidget(self.label_21)

        self.comboBox_5 = QComboBox(self.widget4)
        self.comboBox_5.addItem(QString())
        self.comboBox_5.addItem(QString())
        self.comboBox_5.addItem(QString())
        self.comboBox_5.addItem(QString())
        self.comboBox_5.addItem(QString())
        self.comboBox_5.addItem(QString())
        self.comboBox_5.addItem(QString())
        self.comboBox_5.addItem(QString())
        self.comboBox_5.setObjectName(u"comboBox_5")

        self.horizontalLayout_14.addWidget(self.comboBox_5)

        self.widget5 = QWidget(self.tab_4)
        self.widget5.setObjectName(u"widget5")
        self.widget5.setGeometry(QRect(210, 310, 361, 26))
        self.horizontalLayout_15 = QHBoxLayout(self.widget5)
        self.horizontalLayout_15.setObjectName(u"horizontalLayout_15")
        self.horizontalLayout_15.setContentsMargins(0, 0, 0, 0)
        self.label_22 = QLabel(self.widget5)
        self.label_22.setObjectName(u"label_22")
        self.label_22.setFont(font5)

        self.horizontalLayout_15.addWidget(self.label_22)

        self.lineEdit_8 = QLineEdit(self.widget5)
        self.lineEdit_8.setObjectName(u"lineEdit_8")

        self.horizontalLayout_15.addWidget(self.lineEdit_8)

        self.tabWidget.addTab(self.tab_4, QString())

        self.gridLayout_5.addWidget(self.tabWidget, 1, 1, 1, 1)

        MainWindow.setCentralWidget(self.centralwidget)
       # self.frame_4.raise()
       # self.tabWidget.raise()
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)
        QWidget.setTabOrder(self.UserId_2, self.pushButton)
        QWidget.setTabOrder(self.pushButton, self.pushButton_2)
        QWidget.setTabOrder(self.pushButton_2, self.UserId_4)
        QWidget.setTabOrder(self.UserId_4, self.UserId_3)
        QWidget.setTabOrder(self.UserId_3, self.tabWidget)
        QWidget.setTabOrder(self.tabWidget, self.UserId)

        self.retranslateUi(MainWindow)

        self.tabWidget.setCurrentIndex(3)


        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.label_16.setText(QCoreApplication.translate("MainWindow", u"Car detection and Tracking System", None))
        self.admin_log_2.setText(QCoreApplication.translate("MainWindow", u"Login to your Account", None))
        self.label.setText("")
        self.label_2.setText("")
        self.UserId.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Enter User ID", None))
        self.label_3.setText("")
        self.UserId_2.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Enter Password", None))
        self.pushButton.setText(QCoreApplication.translate("MainWindow", u"Login", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab), QCoreApplication.translate("MainWindow", u"User Login", None))
        self.label_4.setText("")
        self.admin_log_3.setText(QCoreApplication.translate("MainWindow", u"Admin Login", None))
        self.label_5.setText("")
        self.UserId_3.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Enter Admin ID", None))
        self.label_6.setText("")
        self.UserId_4.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Enter Password", None))
        self.pushButton_2.setText(QCoreApplication.translate("MainWindow", u"Login", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_2), QCoreApplication.translate("MainWindow", u"Admin Login", None))
        self.label_9.setText(QCoreApplication.translate("MainWindow", u"Gender", None))
        self.radioButton.setText(QCoreApplication.translate("MainWindow", u"Male", None))
        self.radioButton_2.setText(QCoreApplication.translate("MainWindow", u"Female", None))
        self.label_8.setText(QCoreApplication.translate("MainWindow", u"Last Name", None))
        self.lineEdit_2.setText("")
        self.lineEdit_2.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Enter Last Name", None))
        self.label_10.setText(QCoreApplication.translate("MainWindow", u"Email", None))
        self.lineEdit_3.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Enter Email", None))
        self.label_12.setText(QCoreApplication.translate("MainWindow", u"Cell #", None))
        self.lineEdit_4.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Enter Number", None))
        self.label_11.setText(QCoreApplication.translate("MainWindow", u"City", None))
        self.comboBox.setItemText(0, QCoreApplication.translate("MainWindow", u"None", None))
        self.comboBox.setItemText(1, QCoreApplication.translate("MainWindow", u"Islamabad", None))
        self.comboBox.setItemText(2, QCoreApplication.translate("MainWindow", u"Lahore", None))
        self.comboBox.setItemText(3, QCoreApplication.translate("MainWindow", u"Karachi", None))
        self.comboBox.setItemText(4, QCoreApplication.translate("MainWindow", u"Peshawar", None))

        self.label_13.setText(QCoreApplication.translate("MainWindow", u"Password", None))
        self.lineEdit_5.setInputMask("")
        self.lineEdit_5.setText("")
        self.lineEdit_5.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Enter password", None))
        self.label_14.setText(QCoreApplication.translate("MainWindow", u"C Password", None))
        self.lineEdit_6.setInputMask("")
        self.lineEdit_6.setText("")
        self.lineEdit_6.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Enter password", None))
        self.label_7.setText(QCoreApplication.translate("MainWindow", u"First Name", None))
        self.lineEdit.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Enter First Name", None))
        self.pushButton_3.setText(QCoreApplication.translate("MainWindow", u"SignUp", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_3), QCoreApplication.translate("MainWindow", u"Signup", None))
        self.pushButton_4.setText(QCoreApplication.translate("MainWindow", u"Start Tracking", None))
        self.label_17.setText(QCoreApplication.translate("MainWindow", u"Registration Number", None))
        self.lineEdit_7.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Enter Registration Number", None))
        self.label_18.setText(QCoreApplication.translate("MainWindow", u"Car Company", None))
        self.comboBox_2.setItemText(0, QCoreApplication.translate("MainWindow", u"Suzuki", None))
        self.comboBox_2.setItemText(1, QCoreApplication.translate("MainWindow", u"Honda", None))
        self.comboBox_2.setItemText(2, QCoreApplication.translate("MainWindow", u"BMW", None))
        self.comboBox_2.setItemText(3, QCoreApplication.translate("MainWindow", u"Mercedes", None))
        self.comboBox_2.setItemText(4, QCoreApplication.translate("MainWindow", u"Kia", None))
        self.comboBox_2.setItemText(5, QCoreApplication.translate("MainWindow", u"Toyota", None))

        self.label_19.setText(QCoreApplication.translate("MainWindow", u"Car Model", None))
        self.comboBox_3.setItemText(0, QCoreApplication.translate("MainWindow", u"2019", None))
        self.comboBox_3.setItemText(1, QCoreApplication.translate("MainWindow", u"2018", None))
        self.comboBox_3.setItemText(2, QCoreApplication.translate("MainWindow", u"2017", None))
        self.comboBox_3.setItemText(3, QCoreApplication.translate("MainWindow", u"2016", None))
        self.comboBox_3.setItemText(4, QCoreApplication.translate("MainWindow", u"2015", None))
        self.comboBox_3.setItemText(5, QCoreApplication.translate("MainWindow", u"2014", None))
        self.comboBox_3.setItemText(6, QCoreApplication.translate("MainWindow", u"2013", None))
        self.comboBox_3.setItemText(7, QCoreApplication.translate("MainWindow", u"2012", None))
        self.comboBox_3.setItemText(8, QCoreApplication.translate("MainWindow", u"2011", None))

        self.label_20.setText(QCoreApplication.translate("MainWindow", u"Car Color", None))
        self.comboBox_4.setItemText(0, QCoreApplication.translate("MainWindow", u"White", None))
        self.comboBox_4.setItemText(1, QCoreApplication.translate("MainWindow", u"Gray", None))
        self.comboBox_4.setItemText(2, QCoreApplication.translate("MainWindow", u"Silver", None))
        self.comboBox_4.setItemText(3, QCoreApplication.translate("MainWindow", u"Black", None))
        self.comboBox_4.setItemText(4, QCoreApplication.translate("MainWindow", u"Metalic Gray", None))
        self.comboBox_4.setItemText(5, QCoreApplication.translate("MainWindow", u"Meroon", None))

        self.label_21.setText(QCoreApplication.translate("MainWindow", u"Registration City", None))
        self.comboBox_5.setItemText(0, QCoreApplication.translate("MainWindow", u"Islamabad", None))
        self.comboBox_5.setItemText(1, QCoreApplication.translate("MainWindow", u"Peshawar", None))
        self.comboBox_5.setItemText(2, QCoreApplication.translate("MainWindow", u"Quetta", None))
        self.comboBox_5.setItemText(3, QCoreApplication.translate("MainWindow", u"Gilgit", None))
        self.comboBox_5.setItemText(4, QCoreApplication.translate("MainWindow", u"AJK", None))
        self.comboBox_5.setItemText(5, QCoreApplication.translate("MainWindow", u"Lahore", None))
        self.comboBox_5.setItemText(6, QCoreApplication.translate("MainWindow", u"Rawalpindi", None))
        self.comboBox_5.setItemText(7, QCoreApplication.translate("MainWindow", u"Karachi", None))

        self.label_22.setText(QCoreApplication.translate("MainWindow", u"Location of Track", None))
        self.lineEdit_8.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Enter City", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_4), QCoreApplication.translate("MainWindow", u"Add Car Details", None))
        #retranslateUi

