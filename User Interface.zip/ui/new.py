import sys
from PyQt5.QtCore import pyqtSlot
from PyQt5.QtWidgets import QApplication,QDialog
from PyQt5.uic import loadUi

class lifecoding(QDialog):
    def __init__(self):
        super(lifecoding,self).__init__()
        loadUi('App.ui',self)
        self.setWindowTitle('Car detection')
        
app=QApplication(sys.argv)
widget=lifecoding()
widget.show()
sys.exit(app.exec_())