import sys
from typing import Type

from PyQt5.QtCore import pyqtSlot
from PyQt5.QtWidgets import QApplication,QDialog
from PyQt5.uic import loadUi
class project(QDialog):
    def __init__(self):
        super(project,self).__init__()
        loadUi('App.ui',self)
      #  self.windowTitle('sdfsd')
app=QApplication(sys.argv)
wid=project()
wid.show()
sys.exit(app.exec_())
